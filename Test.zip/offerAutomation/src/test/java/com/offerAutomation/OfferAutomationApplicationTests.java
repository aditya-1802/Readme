package com.offerAutomation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OfferAutomationApplicationTests {

	@Test
	void contextLoads() {
	}

}
