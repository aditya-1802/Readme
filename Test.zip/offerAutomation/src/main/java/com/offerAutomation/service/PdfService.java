package com.offerAutomation.service;

import com.offerAutomation.entity.Candidate;
import com.itextpdf.kernel.pdf.*;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;

import org.springframework.stereotype.Service;

import java.io.File;

@Service
public class PdfService {

    public String generateOfferPdf(Candidate c, String token) {

        try {
            File folder = new File("offers");
            if (!folder.exists()) folder.mkdir();

            String path = "offers/offer_" + token + ".pdf";

            PdfWriter writer = new PdfWriter(path);
            PdfDocument pdf = new PdfDocument(writer);
            Document document = new Document(pdf);

            document.add(new Paragraph("OFFER LETTER\n\n"));
            document.add(new Paragraph("Dear " + c.getName() + ","));
            document.add(new Paragraph("Position: " + c.getPosition()));
            document.add(new Paragraph("Salary: ₹" + c.getSalary()));
            document.add(new Paragraph("\nTerms & Conditions:"));
            document.add(new Paragraph("• You must comply with company policies."));
            document.add(new Paragraph("• This offer is confidential."));
            document.add(new Paragraph("\nRegards,\nHR Department"));

            document.close();
            return path;

        } catch (Exception e) {
            throw new RuntimeException("PDF generation failed", e);
        }
    }
}
