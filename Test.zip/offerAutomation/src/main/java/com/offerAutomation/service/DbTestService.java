package com.offerAutomation.service;

import jakarta.persistence.EntityManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DbTestService {

    @Autowired
    private EntityManager entityManager;

    public void testDb() {
        entityManager.createNativeQuery("SELECT 1").getSingleResult();
        System.out.println("✅ DATABASE CONNECTED SUCCESSFULLY");
    }
}
