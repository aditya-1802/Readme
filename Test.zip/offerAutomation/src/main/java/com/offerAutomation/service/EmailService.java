package com.offerAutomation.service;

import com.offerAutomation.entity.Candidate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.*;
import org.springframework.stereotype.Service;

import jakarta.mail.internet.MimeMessage;
import java.io.File;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    public void sendOfferMail(Candidate c, String token, String pdfPath) {

        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true);

            helper.setTo(c.getEmail());
            helper.setSubject("Offer Letter - " + c.getPosition());

            String body = """
                Dear %s,

                Please find attached your offer letter.

                Terms & Conditions:
                - Read the offer carefully
                - Accept only if you agree

                ACCEPT:
                http://localhost:8080/offer/accept?token=%s

                REJECT:
                http://localhost:8080/offer/reject?token=%s

                Regards,
                HR Team
                """.formatted(c.getName(), token, token);

            helper.setText(body);
            helper.addAttachment("OfferLetter.pdf", new File(pdfPath));

            mailSender.send(message);

        } catch (Exception e) {
            throw new RuntimeException("Email sending failed", e);
        }
    }
}
