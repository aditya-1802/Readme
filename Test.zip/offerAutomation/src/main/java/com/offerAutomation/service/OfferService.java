package com.offerAutomation.service;

import com.offerAutomation.entity.Candidate;
import com.offerAutomation.entity.OfferLetter;
import com.offerAutomation.repository.OfferRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
public class OfferService {

    @Autowired
    private PdfService pdfService;

    @Autowired
    private EmailService emailService;

    @Autowired
    private OfferRepository offerRepository;

    public void processOffer(Candidate candidate) {

        // 1. Generate secure token
        String token = UUID.randomUUID().toString();

        // 2. Generate PDF
        String pdfPath = pdfService.generateOfferPdf(candidate, token);

        // 3. Save offer details
        OfferLetter offer = new OfferLetter();
        offer.setCandidate(candidate);
        offer.setToken(token);
        offer.setPdfPath(pdfPath);
        offer.setExpiryTime(LocalDateTime.now().plusDays(7));

        offerRepository.save(offer);

        // 4. Send email
        emailService.sendOfferMail(candidate, token, pdfPath);
    }
}
