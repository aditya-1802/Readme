package com.offerAutomation.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class MailTestService {

    @Autowired
    private JavaMailSender mailSender;

    public void sendTestMail() {

        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo("YOUR_GMAIL@gmail.com");
        message.setSubject("Mail Test Successful");
        message.setText("Spring Boot mail configuration is working.");

        mailSender.send(message);

        System.out.println("✅ MAIL SENT SUCCESSFULLY");
    }
}
