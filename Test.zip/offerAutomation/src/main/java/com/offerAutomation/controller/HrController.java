package com.offerAutomation.controller;

import com.offerAutomation.entity.Candidate;
import com.offerAutomation.repository.CandidateRepository;
import com.offerAutomation.service.OfferService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class HrController {

    @Autowired
    private CandidateRepository candidateRepository;

    @Autowired
    private OfferService offerService;

    // HR Dashboard
    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("candidates", candidateRepository.findAll());
        return "dashboard";
    }

    // Send Offer (single candidate for now)
    @PostMapping("/send-offer")
    public String sendOffer(@ModelAttribute Candidate candidate) {

        candidate.setStatus("PENDING");
        candidateRepository.save(candidate);

        offerService.processOffer(candidate);

        return "redirect:/dashboard";
    }
}
