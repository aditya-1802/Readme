package com.offerAutomation.controller;

import com.offerAutomation.entity.OfferLetter;
import com.offerAutomation.repository.OfferRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@Controller
@RequestMapping("/offer")
public class OfferResponseController {

    @Autowired
    private OfferRepository offerRepository;

    @GetMapping("/accept")
    public String acceptOffer(@RequestParam String token) {

        OfferLetter offer = offerRepository.findByToken(token).orElseThrow();

        if (offer.getExpiryTime().isBefore(LocalDateTime.now())) {
            return "rejected";
        }

        offer.getCandidate().setStatus("ACCEPTED");
        offerRepository.save(offer);

        return "accepted";
    }

    @GetMapping("/reject")
    public String rejectOffer(@RequestParam String token) {

        OfferLetter offer = offerRepository.findByToken(token).orElseThrow();
        offer.getCandidate().setStatus("REJECTED");
        offerRepository.save(offer);

        return "rejected";
    }
}
