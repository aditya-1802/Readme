package com.offerAutomation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.offerAutomation.entity.Candidate;

public interface CandidateRepository extends JpaRepository<Candidate, Long> {
}
