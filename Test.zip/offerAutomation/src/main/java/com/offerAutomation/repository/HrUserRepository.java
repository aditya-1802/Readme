package com.offerAutomation.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.offerAutomation.entity.HrUser;

public interface HrUserRepository extends JpaRepository<HrUser, Long> {

    Optional<HrUser> findByEmail(String email);
}
