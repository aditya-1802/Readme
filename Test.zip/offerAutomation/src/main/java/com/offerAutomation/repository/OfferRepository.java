package com.offerAutomation.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.offerAutomation.entity.OfferLetter;

public interface OfferRepository extends JpaRepository<OfferLetter, Long> {

    Optional<OfferLetter> findByToken(String token);
}
