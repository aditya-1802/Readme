package com.offerAutomation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.offerAutomation.service.DbTestService;
import com.offerAutomation.service.MailTestService;

import jakarta.annotation.PostConstruct;

@SpringBootApplication
public class OfferAutomationApplication {
	
	
	public static void main(String[] args) {
		SpringApplication.run(OfferAutomationApplication.class, args);
	}
	
//	@Autowired
//    DbTestService dbTestService;
//
//    @PostConstruct
//    public void test() {
//    	dbTestService.testDb();
//    }
//    
//    
//    
//    @Autowired
//    MailTestService mailTestService;
//
//    @PostConstruct
//    public void testMail() {
//        mailTestService.sendTestMail();
//    }

}
